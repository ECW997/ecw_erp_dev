<?php
class InvoiceOutstandingReport extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Report_info');
        $this->load->model('Commeninfo');
        $this->api_token = $this->session->userdata('api_token');
    }

    public function index() {
        $result['menuaccess'] = json_decode(json_encode($this->Commeninfo->getMenuPrivilege($this->api_token, '')['data'] ?? []));
        $result['report'] = []; // Default: no data
        if ($this->input->method() === 'post') {
            $form_data = $this->input->post();
            $result['report'] = $this->Report_info->getAllOutstandingInvoices($this->api_token, $form_data);
        }
        $this->load->view('invoice_outstanding_report', $result);
    }
}